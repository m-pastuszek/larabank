import Litstack from 'litstack';

require('./service/component.service');

const store = {
    // Add store modules here.
};

new Litstack({
    store,
});
