<?php

return [
    'products' => 'Products',
    'product'  => 'Product',
];
