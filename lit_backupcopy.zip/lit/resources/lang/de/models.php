<?php

return [
    'products' => 'Produkte',
    'product'  => 'Produkt',
];
