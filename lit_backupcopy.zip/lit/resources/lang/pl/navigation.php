<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Navigation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines translate content located in any navigation
    | of the litstack application.
    |
    */

    'user_administration' => 'Zarządzanie kontem',
];
