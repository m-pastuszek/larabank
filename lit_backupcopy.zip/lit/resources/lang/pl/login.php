<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the translations for the login page.
    |
    */

    'login'             => 'Logowanie',
    'do_login'          => 'Logowanie',
    'email_or_username' => 'E-mail lub nazwa użytkownika',
    'remember_me'       => 'Zapamiętaj mnie',
    'forgot_password'   => 'zapomniałem hasło',
    'failed'            => 'Wprowadzono niepoprawne dane logowania.',
];
