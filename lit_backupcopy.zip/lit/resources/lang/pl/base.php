<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Base Language Lines
    |--------------------------------------------------------------------------
    |
    | Base translations are words or word combinations that can occur frequently
    | and do not specifically belong to any part of the litstack application.
    |
    */

    'no_item_found'    => 'Nic nie znaleziono',
    'no_item_selected' => 'Nic nie zaznaczono',
    'item_delete'      => 'usunąć :item',
    'item_deleted'     => ':item został usunięty',
    'item_enter'       => 'wprowadź :item',
    'item_create'      => 'utwórz :item',
    'item_remove'      => 'usuń :item',
    'item_select'      => 'zaznacz :item',
    'item_order'       => 'sortuj :item',
    'item_ordered'     => ':item posortowane',
    'item_search'      => 'szukaj :item',
    'item_add'         => 'dodaj :item',
    'item_added'       => ':item został dodany',
    'item_assign'      => 'przypisz :item',
    'item_settings'    => ':item settings',
    'item_item'        => ':item item',
    'user_hello'       => 'Witaj :user',
    'profile'          => 'profil',
    'settings'         => 'ustawienia',
    'password'         => 'hasło',
    'drag_and_drop'    => 'Przeciągnij i upuść',
    'name'             => 'nazwa',
    'user'             => 'użytkownik',
    'users'            => 'użytkownicy',
    'email'            => 'e-mail',
    'email_address'    => 'adres e-mail',
    'language'         => 'Język',
    'system_language'  => 'Język systemu',
    'general'          => 'główne informacje',
    'security'         => 'Bezpieczeństwo',
    'device'           => 'urządzenie',
    'logout'           => 'wyloguj',
    'change_order'     => 'zmień sortowanie',
    'login'            => 'zaloguj',
    'close'            => 'zamknij',
    'save'             => 'zapisz',
    'saved'            => 'zapisano',
    'done'             => 'wykonano',
    'undo_changes'     => 'Cofnij zmiany',
    'image'            => 'grafika',
    'crop'             => 'kadruj',
    'search'           => 'szukaj',
    'first_name'       => 'Imię',
    'last_name'        => 'Nazwisko',
    'username'         => 'Nazwa użytkownika',
    'cancel'           => 'anuluj',
    'location'         => 'lokalizacja',
    'action'           => 'akcja|akcje',
    'role'             => 'rola',
    'roles'            => 'role',
    'read'             => 'wyświetl',
    'update'           => 'aktualizuj',
    'sort'             => 'sortuj',
    'create'           => 'utwórz',
    'delete'           => 'usuń',
    'permissions'      => 'uprawnienia',
    'group'            => 'grupa',
    'unauthorized'     => 'Nie masz uprawnień do wykonania tej akcji!',
    'page'             => 'strona',
    'all'              => 'wszystkie',
    'pages'            => 'strony',
    'hello'            => 'witaj',
    'filter'           => 'filtr',
    'toggle_all'       => 'włącz wszystko',
    'messages'         => [
        'order_changed' => 'Pomyślnie zmieniono sortowanie',
        'are_you_sure'  => 'Czy na pewno? Tej akcji nie można cofnąć.',
    ],
];
