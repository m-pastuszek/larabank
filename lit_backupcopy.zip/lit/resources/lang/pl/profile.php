<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Profile Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines translate all parts of the profile settings
    | page.
    |
    */

    'new_password'         => 'Nowe hasło',
    'new_password_confirm' => 'Potwierdź nowe hasło',
    'current_password'     => 'Aktualne hasło',
    'change_password'      => 'Zmień hasło',
    'messages'             => [
        'language' => 'W tym języku będzie wyświetlany panel administracyjny.',
    ],
];
