<?php

namespace Lit\Config\Charts;

use App\Models\User;
use App\Models\User as Client;
use Ignite\Chart\Chart;
use Ignite\Chart\Config\NumberChartConfig;

class ClientsCountInactiveNumberChartConfig extends NumberChartConfig
{
    /**
     * The model class of the chart.
     *
     * @var string
     */
    public $model = Client::class;

    /**
     * Chart title.
     *
     * @return string
     */
    public function title(): string
    {
        return 'Nieaktywne konta';
    }

    /**
     * Mount.
     *
     * @param Chart $chart
     * @return void
     */
    public function mount(Chart $chart)
    {
        //
    }

    /**
     * Calculate value.
     *
     * @param Builder $query
     * @return int
     */
    public function value($query)
    {
        return $this->count($query->where('status', 0));
    }
}

// TODO: Wyświetlanie wszystkich nieaktywnych kont bez względu na ustawiony przedział czasu
