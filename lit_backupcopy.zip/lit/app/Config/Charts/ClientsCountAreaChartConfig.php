<?php

namespace Lit\Config\Charts;

use App\Models\User;
use Ignite\Chart\Chart;
use Illuminate\Support\Collection;
use Ignite\Chart\Config\AreaChartConfig;

class ClientsCountAreaChartConfig extends AreaChartConfig
{
    /**
     * The model class of the chart.
     *
     * @var string
     */
    public $model = User::class;

    /**
     * Chart title.
     *
     * @return string
     */
    public function title(): string
    {
        return 'Nowi klienci banku';
    }

    /**
     * Mount.
     *
     * @param Chart $chart
     * @return void
     */
    public function mount(Chart $chart)
    {
        //
    }

    /**
     * Calculate value.
     *
     * @param Builder $query
     * @return integer
     */
    public function value($query)
    {
        return $this->count($query);
    }
}
