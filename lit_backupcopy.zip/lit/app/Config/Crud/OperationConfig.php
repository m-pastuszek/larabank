<?php

namespace Lit\Config\Crud;

use Ignite\Crud\CrudShow;
use Ignite\Crud\CrudIndex;
use Ignite\Crud\Config\CrudConfig;
use Illuminate\Support\Str;

use App\Models\Operation;
use Lit\Http\Controllers\Crud\OperationController;

class OperationConfig extends CrudConfig
{
    /**
     * Model class.
     *
     * @var string
     */
    public $model = Operation::class;

    /**
     * Controller class.
     *
     * @var string
     */
    public $controller = OperationController::class;

    /**
     * Model singular and plural name.
     *
     * @param Operation|null operation
     * @return array
     */
    public function names(Operation $operation = null)
    {
        return [
            'singular' => 'Operacja',
            'plural'   => 'Operacje',
        ];
    }

    /**
     * Get crud route prefix.
     *
     * @return string
     */
    public function routePrefix()
    {
        return 'operations';
    }

    /**
     * Build index page.
     *
     * @param \Ignite\Crud\CrudIndex $page
     * @return void
     */
    public function index(CrudIndex $page)
    {
        // TODO: Niewyświetlające się relacje...
        $page->table(function ($table) {
            $table->col('ID Operacji')->value('{id}');
            $table->col('Typ operacji')->value('{type.name}');
            $table->col('Nazwa przelewu')->value('{transaction.title}');
            $table->col('Status')->value('{status.name}');
        });
    }

    /**
     * Setup show page.
     *
     * @param \Ignite\Crud\CrudShow $page
     * @return void
     */
    public function show(CrudShow $page)
    {
        $page->card(function($form) {

            $form->input('title');

        });
    }
}
