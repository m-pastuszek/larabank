<?php

namespace Lit\Config\Crud;

use Ignite\Crud\CrudShow;
use Ignite\Crud\CrudIndex;
use Ignite\Crud\Config\CrudConfig;
use Illuminate\Support\Str;

use App\Models\OperationType;
use Lit\Http\Controllers\Crud\OperationTypeController;

class OperationTypeConfig extends CrudConfig
{
    /**
     * Model class.
     *
     * @var string
     */
    public $model = OperationType::class;

    /**
     * Controller class.
     *
     * @var string
     */
    public $controller = OperationTypeController::class;

    /**
     * Model singular and plural name.
     *
     * @param OperationType|null operationType
     * @return array
     */
    public function names(OperationType $operationType = null)
    {
        return [
            'singular' => 'OperationType',
            'plural'   => 'OperationTypes',
        ];
    }

    /**
     * Get crud route prefix.
     *
     * @return string
     */
    public function routePrefix()
    {
        return 'operation-types';
    }

    /**
     * Build index page.
     *
     * @param \Ignite\Crud\CrudIndex $page
     * @return void
     */
    public function index(CrudIndex $page)
    {
        $page->table(function ($table) {

            $table->col('Title')->value('{title}')->sortBy('title');

        })->search('title');  
    }

    /**
     * Setup show page.
     *
     * @param \Ignite\Crud\CrudShow $page
     * @return void
     */
    public function show(CrudShow $page)
    {
        $page->card(function($form) {

            $form->input('title');
            
        });
    }
}
