<?php

namespace Lit\Config\Crud;

use App\Models\BankCode;
use App\Models\BankProduct;
use App\Models\ClientBankProduct;
use App\Models\User;
use App\Models\Voivodeship;
use Ignite\Crud\CrudShow;
use Ignite\Crud\CrudIndex;
use Ignite\Crud\Config\CrudConfig;

use Lit\Config\Charts\ClientsCountAreaChartConfig;
use Lit\Http\Controllers\Crud\ClientController;
use Lit\Config\Charts\ClientsCountInactiveNumberChartConfig;

class ClientConfig extends CrudConfig
{
    /**
     * Model class.
     *
     * @var string
     */
    public $model = User::class;

    /**
     * Controller class.
     *
     * @var string
     */
    public $controller = ClientController::class;

    /**
     * Model singular and plural name.
     *
     * @param User|null user
     * @return array
     */
    public function names(User $user = null)
    {
        return [
            'singular' => 'Klient',
          //  'singular' => 'Klient: ' . $user->first_name . ' ' . $user->last_name ?? 'Klient',
            'plural'   => 'Klienci',
        ];
    }

    /**
     * Get crud route prefix.
     *
     * @return string
     */
    public function routePrefix()
    {
        return 'clients';
    }

    /**
     * Build index page.
     *
     * @param \Ignite\Crud\CrudIndex $page
     * @return void
     */
    public function index(CrudIndex $page)
    {
        $page->chart(ClientsCountAreaChartConfig::class)->height('120px')->variant('white');
        $page->table(function ($table) {
            $table->avatar('Awatar')->src('{image.profile_photo_path.sm}');
            $table->col('Imię i nazwisko')->value('{first_name} {last_name}');
            $table->col('Adres e-mail')->value('{email}');
            $table->col('PESEL')->value('{pesel_number}');
            $table->col('Adres zamieszkania')->value('{street} {street_number}; {zip} {city}');
            $table->col('Status')->value('status', [
                '1' => '<div class="badge badge-warning">Nieaktywny</div>',
                '2'  => '<div class="badge badge-success">Aktywny</div>',
                '3'  => '<div class="badge badge-info">Dezaktywowany</div>',
                '4'  => '<div class="badge badge-danger">Zablokowany</div>',
            ])->sortBy('status');

        })->search('first_name', 'last_name', 'pesel_number', 'email', 'city')
            ->sortBy([
                'last_name.asc'     => 'Nazwisko A-Z',
                'last_name.desc'    => 'Nazwisko Z-A',
                'pesel_number.asc'  => 'PESEL rosnąco',
                'pesel_number.desc' => 'PESEL malejąco',
                'created_at.asc'    => 'Data dołączenia rosnąco',
                'created_at.desc'   => 'Data dołączenia malejąco',
            ])
            ->filter([
                'Status konta' => [
                    'active'        => 'Aktywne',
                    'inactive'      => 'Nieaktywne',
                    'deactivated'   => 'Dezaktywowane',
                    'blocked'       => 'Zablokowane'
                ],
            ]);
    }

    /**
     * Setup show page.
     *
     * @param \Ignite\Crud\CrudShow $page
     * @return void
     */
    public function show(CrudShow $page)
    {
        $page->group(function ($page) {
            // Informacje o kliencie
            $page->card(function ($form) {
                $form->input('first_name')
                    ->title('Imię')
                    ->width(1 / 2);
                $form->input('last_name')
                    ->title('Nazwisko')
                    ->width(1 / 2);
                $form->input('street')
                    ->title('Ulica')
                    ->width(2 / 3);
                $form->input('street_number')
                    ->title('Numer domu')
                    ->updateRules('numeric')
                    ->width(1 / 3);
                $form->select('voivodeship_id')
                    ->title('Województwo')
                    ->options(Voivodeship::all()
                        ->mapWithKeys(fn($voivodeship) => [$voivodeship->id => $voivodeship->name])->toArray())
                    ->rules('int');
                $form->input('zip')
                    ->title('Kod pocztowy')
                    ->width(1 / 3);
                $form->input('city')
                    ->title('Miasto')
                    ->width(2 / 3);
                $form->input('pesel_number')
                    ->title('Numer PESEL')
                    ->readOnly();
                $form->datetime('birth_date')
                    ->title('Data urodzenia')
                    ->formatted('LL')
                    ->readOnly()
                    ->width(6);
                $form->select('status')
                    ->title('Status konta')
                    ->options([
                        1 => 'Nieaktywny',
                        2 => 'Aktywny',
                        3 => 'Dezaktywowany',
                        4 => 'Zablokowany'
                    ]);
            })->title('Informacje o kliencie');

            // Produkty bankowe
            $page->card(function ($form) {
                $form->relation('clientBankProducts')
                    ->preview(function ($table) {
                        $table->col('IBAN')->value('{iban}');
                    })->title('');
            })->title('Numery rachunków');
        })->width(8);

        $page->group(function ($page) {
            $page->card(function ($form) {
                $form->datetime('created_at')
                    ->title('Data założenia konta')
                    ->formatted('lll')
                    ->onlyDate(false)
                    ->hint('Data rejestracji klienta w banku.');
                $form->datetime('updated_at')
                    ->title('Data ostatniej zmiany')
                    ->formatted('lll')
                    ->onlyDate(false)
                    ->hint('Data ostatniej zmiany danych klienta.');
                $form->input('locale')
                    ->title('Język panelu')
                    ->info('Obecnie panel klienta wyświetlany jest tylko w języku polskim.');
            });
        })->width(4);
    }
}
